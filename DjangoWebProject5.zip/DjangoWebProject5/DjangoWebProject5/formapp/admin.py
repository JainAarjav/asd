from django.contrib import admin
from . import models

class StudentAdmin(admin.ModelAdmin):
    list_display = ('name','rollno')
admin.site.register(models.StudentModel,StudentAdmin)

# Register your models here.
