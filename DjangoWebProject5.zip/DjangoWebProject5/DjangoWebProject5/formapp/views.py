from django.http import HttpResponseRedirect
from django.shortcuts import render
from .forms import StudentForm
from .models import StudentModel

def index(request):
    return render(request,'index.html',{'stud_form':StudentForm()})

def studcreate(request):
    if request.method == 'POST':
        stud_form = StudentForm(request.POST)
        
        if stud_form.is_valid():
            #name = stud_form.cleaned_data['name']  ...to extract data from form
            #request.session['name'] = name    ..to access name = request.session['name']
            student = stud_form.save(commit=False)
            student.save()
            
    return HttpResponseRedirect('/')
           
def stud(request):
    students = StudentModel.objects.all()
    return render(request,'stud.html',{'students':students})   

def mystud(request,roll_no):
    student = StudentModel.objects.filter(rollno = roll_no)
    if(student[0].rollno>20):
        return render(request,'mystud.html',{'student':student[0],'stud_form':StudentForm()})
    else:
        return render(request,'mystud.html',{'message':'You are below 20'})  
    
def deleteStudent(request,roll_no):
    if(request.method == 'POST'):
        StudentModel.objects.filter(rollno=roll_no).delete()
        return HttpResponseRedirect('/stud/')
    
def updateStudent(request,roll_no):
    if(request.method == 'POST'):
        stud_form = StudentForm(request.POST)
        if stud_form.is_valid():
            rn = stud_form.cleaned_data['rollno']
            name = stud_form.cleaned_data['name']
            print(rn)
            StudentModel.objects.filter(rollno = roll_no).update(name=name,rollno=rn)
            return HttpResponseRedirect('/stud/')
#how to access form element
#indv element page
    