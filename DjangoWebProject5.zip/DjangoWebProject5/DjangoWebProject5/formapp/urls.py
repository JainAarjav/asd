from django.urls import path,include
from . import views
urlpatterns = [
        path('',views.index),
        path('createstud/',views.studcreate),
        path('stud/',views.stud),
        path('student/<roll_no>',views.mystud),
        path('delstud/<roll_no>',views.deleteStudent),
        path('updatestud/<roll_no>',views.updateStudent),
    ]