from django.db import models

class StudentModel(models.Model):
    name = models.CharField(max_length = 50)
    rollno = models.PositiveIntegerField()
    
    

# Create your models here.
