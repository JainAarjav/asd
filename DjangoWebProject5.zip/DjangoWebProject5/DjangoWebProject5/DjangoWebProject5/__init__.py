"""
Package for DjangoWebProject5.
"""
